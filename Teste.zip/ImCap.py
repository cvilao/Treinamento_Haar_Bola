import cv2
import numpy as np
import os

drawing = False # true if mouse is pressed
ix,iy = -1,-1
pos = open('positives.txt', 'w')
path, dirs, files = os.walk('./Positive').next()
loop = True
try:
    init = np.loadtxt('stoped.txt')
except:
    init = 0

# mouse callback function
def select(event,x,y,flags,param):
    global ix,iy,drawing
    img = np.copy(img0)
    txt = ''
    
    if event == cv2.EVENT_LBUTTONDOWN:
        if not(drawing):
            drawing = True
            ix,iy = x,y
            cte = np.array([0, 0, 0, 0])
        else:
            drawing = False
            txt = '/Positive/'+files[fl]+' 1 '+str(ix)+' '+str(iy)+' '+str(x-ix)+' '+str(y-iy)
            cte = np.array([ix, iy, x, y])
            print txt
    
    elif event == cv2.EVENT_MOUSEMOVE:
        cv2.line(img, (0, y), (len(img[0]), y), (0,255,255), 1)
        cv2.line(img, (x, 0), (x, len(img)), (0,255,255), 1)
        if drawing == True:
            cv2.rectangle(img,(ix,iy),(x,y),(0,255,0),1)
    
    cv2.rectangle(img,(cte[0],cte[1]),(cte[2],cte[3]),(0,255,0),2)
    cv2.imshow('image',img)

for fl in range(init, len(files)):
    img0 = cv2.imread('./Positive/'+files[fl])
    img0 = cv2.resize(img0, (0,0), fx=0.5, fy=0.5)
    cv2.namedWindow('image')
    cv2.setMouseCallback('image',select)
    cv2.imshow('image',img0)
        
    while(loop):
        #cv2.imshow('image',img)
        k = cv2.waitKey(1) & 0xFF
        if k == 27:
            break
        elif k == ord('q'):
            loop = False
    
    if not(loop):
        #np.savetxt('stoped.txt', np.array([fl]))
        break

cv2.destroyAllWindows()

